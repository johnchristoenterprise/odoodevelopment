# from odoo import api, fields, models
#
#
# class CreateInvoice(models.TransientModel):
#     _name = "create.invoice"
#     _description = "Create Invoice"
# advance_payment_method = fields.Selection([
#     ('delivered', 'Regular invoice'),
#     ('percentage', 'Down payment (percentage)'),
#     ('fixed', 'Down payment (fixed amount)')
# ], string='Create Invoice', default='delivered', required=True,
#     help="A standard invoice is issued with all the order lines ready for invoicing, \
#         according to their invoicing policy (based on ordered or delivered quantity).")
# deduct_down_payments = fields.Boolean('Deduct down payments', default=True)
# has_down_payments = fields.Boolean('Has down payments', readonly=True)
# product_id = fields.Many2one('product.product', string='Down Payment Product', domain=[('type', '=', 'service')])
# count = fields.Integer( string='Order Count')
# amount = fields.Float('Down Payment Amount', digits='Account',
#                       help="The percentage of amount to be invoiced in advance, taxes excluded.")
# fixed_amount = fields.Monetary('Down Payment Amount (Fixed)',
#                                help="The fixed amount to be invoiced in advance, taxes excluded.")
# deposit_account_id = fields.Many2one("account.account", string="Income Account", domain=[('deprecated', '=', False)],
#                                      help="Account used for deposits")
# deposit_taxes_id = fields.Many2many("account.tax", string="Customer Taxes", help="Taxes used for deposits")
