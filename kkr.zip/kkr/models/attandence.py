from odoo import fields, models, api
from datetime import datetime


class BakeryAttandence(models.Model):
    _name = "bakery.attandence"
    _description = "Bakery Attandence"

    name_1 = fields.Char(string='Name', required=True)
    in_time = fields.Datetime(string='In Time', readonly= True)
    out_time = fields.Datetime(string='Out Tme', readonly= True)
    bakery_id = fields.Many2one('bakery.cakes')

    # state = fields.Selection(
    #     [('in_time', 'In Time'), ('out_time', 'Out Time')], string="Time")

    # def action_in(self):
    #     print('gugghjj')
    #     if not self.in_time:
    #         self.in_time = datetime.now()
    #     # self.out_time = datetime.now()

    # def action_out(self):
    #     self.out_time = datetime.today().strftime('%Y-%m-%d')

    @api.onchange('')
    def action_in(self):
        self.in_time = datetime.today().strftime('%Y-%m-%d %H:%M:%S')

    @api.onchange('')
    def action_out(self):
        self.out_time = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
    # @api.onchange('out_time')
    # def out_time(self):
    #     self.out_time = datetime.today().strftime('%Y-%m-%d')

    # def action_in(self):
    #     for order in self:
    #         self.env['bakery.attandence'].search([('button_in', '=', 'in_time')]).write(
    #             {'temporary_reception_date': datetime.date.today()})
    #         order.write({'state': 'temporary'})
