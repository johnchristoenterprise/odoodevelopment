from odoo import api, fields, models, _


class BakeryCakes(models.Model):
    _name = "bakery.cakes"
    _description = "Bakery Cakes"

    name = fields.Char(string='Name', required=True)
    reference = fields.Char(string='Order Reference', required=True, copy=False, readonly=True,
                            default=lambda self: _('New'))
    age = fields.Integer(string='Age')
    gender = fields.Selection([('male', 'Male'),
                               ('female', 'Female'),
                               ('other', 'Other'),
                               ], required=True, default='male')
    bakery_lines = fields.One2many('bakery.cakes.lines', 'ref_id', string="Bakery Lines")
    job_position = fields.Many2one('bakery.configration', string='Job Position')
    note = fields.Text(string='Description')
    state = fields.Selection(
        [('draft', 'Draft'), ('active', 'Active'), ('inactive', 'Inactive'), ('cancel', 'Cancelled'),
         ('emolpyee', 'Create Employee')], default='draft',
        string="Status")
    image = fields.Binary(string="Image")
    amount_untaxed = fields.Integer(string="Untaxed")
    amount_tax = fields.Integer(string="Total tax")
    total = fields.Integer(string="Total")

    def action_active(self):
        self.state = 'active'

    def action_inactive(self):
        self.state = 'inactive'

    def action_draft(self):
        self.state = 'draft'

    def action_cancel(self):
        self.state = 'cancel'

    @api.model
    def create(self, vals):
        if not vals.get('note'):
            vals['note'] = 'New Patient'
        if vals.get('reference', _('New')) == _('New'):
            vals['reference'] = self.env['ir.sequence'].next_by_code('bakery.cakes') or _('New')
        res = super(BakeryCakes, self).create(vals)
        return res

    def bakery_attandence1(self):
        return {
            'name': _('Attendence'),
            'view_mode': 'tree,form',
            'res_model': 'bakery.attandence',
            'type': 'ir.actions.act_window',
            'domain': [('bakery_id', '=', self.id)],
            'context': {
                'default_name_1': self.name, 'default_bakery_id': self.id
            }
        }

    def action_create_employee(self):
        self.state = 'emolpyee'
        _name = self.env['hr.employee'].create({
            'name': self.name,
            'job_position1': self.job_position.id,
            'work_email': self.note,
            'job_title': self.job_position.job_position})


class BakeryCakesLines(models.Model):
    _name = "bakery.cakes.lines"
    _description = "Bakery Cakes Lines"

    product_id = fields.Many2one('product.product', string="Product")
    quantity = fields.Integer(string="Quantity")
    list_price = fields.Integer(string="Unit Price")
    taxes_id = fields.Integer(string="Taxes")
    sub_total = fields.Integer(string="Sub Total", compute='compute_sub_total')
    ref_id = fields.Many2one('bakery.cakes', string="Ref ID")

    @api.onchange('product_id')
    def onchange_product_id(self):
        if self.product_id:
            if self.product_id.list_price:
                self.list_price = self.product_id.list_price

    @api.depends('list_price', 'quantity')
    def compute_sub_total(self):
        for line in self:
            line.sub_total = line.list_price * line.quantity
