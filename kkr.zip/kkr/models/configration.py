from odoo import fields, models

class BakeryConfigration(models.Model):
    _name = "bakery.configration"
    _description = "Bakery Configration"
    _rec_name = 'job_position'

    name = fields.Char(string='Name', required=True)
    description = fields.Char(string='Description')
    job_position = fields.Char(string='Job Position')
