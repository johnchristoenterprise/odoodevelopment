from odoo import fields, models


class HrEmployee(models.Model):
    _inherit = "hr.employee"

    job_position1 = fields.Many2one('bakery.configration', string='Job Position')
